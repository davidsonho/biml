xcopy deployment instructions are here:
http://bidshelper.codeplex.com/wikipage?title=xcopy%20deploy

for BIDS Helper 2012 and BIDS Helper 2014, be sure to unblock the DLLs as noted at the above link